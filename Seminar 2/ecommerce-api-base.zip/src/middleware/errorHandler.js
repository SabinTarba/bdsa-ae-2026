const notFound = (req, res) => {
    res.status(404).json({
        message: `Ruta ${req.method} ${req.originalUrl} nu exista`
    });
}

const errorHandler = (err, req, res, next) => {

    // Erori Prisma frecvente
    if (err.code === "P2002") {
        return res.status(409).json({ message: "Valoarea exista deja" });
    }

    if (err.code === "P2025") {
        return res.status(404).json({ message: "Resursa nu a fost gasita" });
    }

    if (err.code === "P2003") {
        return res.status(409).json({
            message: "Resursa este folosita de alte inregistrari"
        });
    }

    const status = err.status ?? 500;

    if (status === 500) {
        console.error(err);
    }

    res.status(status).json({
        message: status === 500 ? "Eroare interna de server" : err.message
    });
}

export { notFound, errorHandler };
import jwt from "jsonwebtoken";
import { HttpError } from "../utils/httpError.js";
import { AUTH_COOKIE } from "../utils/cookies.js";

export const authenticate = (req, res, next) => {
    const token = req.cookies?.[AUTH_COOKIE];

    if (!token) {
        throw new HttpError(401, "Lipseste token-ul de autentificare");
    }

    let payload;

    try {
        payload = jwt.verify(token, process.env.JWT_SECRET);
    } catch {
        throw new HttpError(401, "Token invalid sau expirat");
    }

    req.user = { id: payload.id, role: payload.role };

    next();
}

export const requireRole = (role) => {
    return (req, res, next) => {
        if (req.user?.role !== role) {
            throw new HttpError(403, "Nu ai dreptul sa accesezi aceasta resursa");
        }

        next();
    };
}
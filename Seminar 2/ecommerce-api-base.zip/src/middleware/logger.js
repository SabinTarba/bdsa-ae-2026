const logger = (req, res, next) => {
    console.log(`${req.method} ${req.url}, body: ${JSON.stringify(req.body || {})}`);
    next();
}

export default logger;

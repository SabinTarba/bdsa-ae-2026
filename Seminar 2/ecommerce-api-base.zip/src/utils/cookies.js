export const AUTH_COOKIE = "token";

const ONE_HOUR = 60 * 60 * 1000; // trebuie sa corespunda cu JWT_EXPIRES_IN

const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/"
};

export const setAuthCookie = (res, token) => {
    res.cookie(AUTH_COOKIE, token, { ...cookieOptions, maxAge: ONE_HOUR });
}

export const clearAuthCookie = (res) => {
    res.clearCookie(AUTH_COOKIE, cookieOptions);
}
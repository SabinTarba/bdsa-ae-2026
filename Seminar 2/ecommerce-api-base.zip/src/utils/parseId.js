import { HttpError } from "./httpError.js";

export const parseId = (value) => {
    const id = Number(value);

    if (!Number.isInteger(id) || id < 1) {
        throw new HttpError(400, "Id invalid");
    }

    return id;
}
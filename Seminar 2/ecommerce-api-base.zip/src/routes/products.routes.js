import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { HttpError } from "../utils/httpError.js";
import { parseId } from "../utils/parseId.js";
import { authenticate, requireRole } from "../middleware/auth.js";

const router = Router();

const sortOptions = {
    price_asc: { price: "asc" },
    price_desc: { price: "desc" },
    newest: { createdAt: "desc" },
    name: { name: "asc" }
};

// GET /api/products?category=...&search=...&sort=price_asc|price_desc|newest|name
router.get("/", async (req, res) => {
    const { category, search, minPrice, maxPrice, inStock, sort = "newest" } = req.query;

    if(minPrice && isNaN(parseFloat(minPrice))) {
        throw new HttpError(400, "Valoare minPrice invalida.");
    }

    if(maxPrice && isNaN(parseFloat(maxPrice))) {
        throw new HttpError(400, "Valoare maxPrice invalida.");
    }

    if (typeof sort !== "string" || !Object.prototype.hasOwnProperty.call(sortOptions, sort)) {
        throw new HttpError(400, "Valoare sort invalida.");
    }

    const products = await prisma.product.findMany({
        where: {
            ...(category && { category }),
            ...(search && { name: { contains: search } }),
            ...(minPrice && { price: { gte: parseFloat(minPrice) } }),
            ...(maxPrice && { price: { lte: parseFloat(maxPrice) } }),
            ...(inStock === "true" && { stock: { gt: 0 } })
        },
        orderBy: sortOptions[sort]
    });

    res.json(products);
});

// GET /api/products/categories
router.get("/categories", async (req, res) => {
    const categories = await prisma.product.findMany({
        distinct: ["category"],
        select: { category: true }
    })
    .then(categories => categories.map(c => c.category));

    res.json(categories);
});

// GET /api/products/:id
router.get("/:id", async (req, res) => {
    const product = await prisma.product.findUnique({
        where: { id: parseId(req.params.id) }
    });

    if (!product) {
        throw new HttpError(404, "Produsul nu exista");
    }

    res.json(product);
});

// POST /api/products
router.post("/", authenticate, requireRole("ADMIN"), async (req, res) => {
    const { name, description, price, category, stock, imageUrl } = req.body;

    if (!name || price == null || !category || stock == null) {
        throw new HttpError(400, "Campuri obligatorii lipsa.");
    }

    const product = await prisma.product.create({
        data: {
            name,
            description,
            price,
            category,
            stock,
            imageUrl
        }
    });

    res.status(201).json(product);
});

// DELETE /api/products/:id
router.delete("/:id", authenticate, requireRole("ADMIN"), async (req, res) => {
    const id = parseId(req.params.id);

    const product = await prisma.product.findUnique({
        where: { id }
    });

    if (!product) {
        throw new HttpError(404, "Produsul nu exista");
    }

    await prisma.product.delete({
        where: { id }
    });

    res.status(204).send();
});

export default router;
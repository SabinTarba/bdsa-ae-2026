import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { prisma } from "../lib/prisma.js";
import { HttpError } from "../utils/httpError.js";
import { setAuthCookie, clearAuthCookie } from "../utils/cookies.js";
import { authenticate } from "../middleware/auth.js";

const router = Router();

export const signToken = (signingdata) => {
    return jwt.sign(
        signingdata,
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN ?? "1h" }
    );
}

// scoatem parola din obiect inainte de a-l trimite clientului
const toPublicUser = ({ password, ...user }) => {
    return user;
}

// POST /api/auth/register
router.post("/register", async (req, res) => {
    const { name, email, password } = req.body;

    const invalid = [name, email, password].some(
        value => typeof value !== "string" || value.trim() === ""
    );

    if (invalid) {
        throw new HttpError(400, "Name, email si password sunt obligatorii");
    }

    if (!/^\S+@\S+\.\S+$/.test(email)) {
        throw new HttpError(400, "Email invalid");
    }

    if (password.length < 6) {
        throw new HttpError(400, "Parola trebuie sa aiba minim 6 caractere");
    }

    const normalizedEmail = email.trim().toLowerCase();

    const existing = await prisma.user.findUnique({
        where: { email: normalizedEmail }
    });

    if (existing) {
        throw new HttpError(409, "Exista deja un cont cu acest email");
    }

    await prisma.user.create({
        data: {
            name: name.trim(),
            email: normalizedEmail,
            password: await bcrypt.hash(password, 10)
        }
    });

    res.status(201).send();
});

// POST /api/auth/login
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    if (typeof email !== "string" || typeof password !== "string") {
        throw new HttpError(400, "email si password sunt obligatorii");
    }

    const user = await prisma.user.findUnique({
        where: { email: email.trim().toLowerCase() }
    });

    const passwordOk = user
        ? await bcrypt.compare(password, user.password)
        : false;

    if (!passwordOk) {
        // acelasi mesaj pentru ambele cazuri, ca sa nu aflam ce emailuri exista
        throw new HttpError(401, "Email sau parola incorecta");
    }

    const publicUser = toPublicUser(user);

    setAuthCookie(res, signToken(publicUser));

    res.json({ user: toPublicUser(publicUser) });
});

// POST /api/auth/logout
router.post("/logout", authenticate, (req, res) => {
    clearAuthCookie(res);
    res.status(204).send();
});

// GET /api/auth/me
router.get("/me", authenticate, async (req, res) => {
    const user = await prisma.user.findUnique({
        where: { id: req.user.id }
    });

    if (!user) {
        throw new HttpError(401, "Utilizatorul nu mai exista");
    }

    res.json(toPublicUser(user));
});

export default router;
import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { HttpError } from "../utils/httpError.js";

const router = Router();

const orderInclude = {
    orderLines: {
        include: {
            product: { select: { id: true, name: true, imageUrl: true } }
        }
    }
};

// POST /api/orders
router.post("/", async (req, res) => {
    const { orderLines } = req.body;

    if (!Array.isArray(orderLines) || orderLines.length === 0) {
        throw new HttpError(400, "Comanda trebuie sa contina cel putin un produs");
    }

    // unificam produsele duplicate: productId -> cantitate totala
    const quantities = new Map();

    for (const item of orderLines) {
        const { productId, quantity } = item ?? {};

        if (!Number.isInteger(productId) || !Number.isInteger(quantity) || quantity < 1) {
            throw new HttpError(
                400,
                "productId si quantity trebuie sa fie numere intregi pozitive"
            );
        }

        quantities.set(productId, (quantities.get(productId) ?? 0) + quantity);
    }

    const order = await prisma.$transaction(async (tx) => {

        const products = await tx.product.findMany({
            where: { id: { in: [...quantities.keys()] } }
        });

        if (products.length !== quantities.size) {
            throw new HttpError(404, "Unul dintre produse nu exista");
        }

        let total = 0;
        const orderLine = [];

        for (const product of products) {
            const quantity = quantities.get(product.id);

            // scadem stocul doar daca exista suficient
            const { count } = await tx.product.updateMany({
                where: { id: product.id, stock: { gte: quantity } },
                data: { stock: { decrement: quantity } }
            });

            if (count === 0) {
                throw new HttpError(409, `Stoc insuficient pentru "${product.name}"`);
            }

            total += product.price * quantity;

            orderLine.push({
                productId: product.id,
                quantity,
                unitPrice: product.price
            });
        }

        return tx.order.create({
            data: {
                userId: req.user.id,
                total: Math.round(total * 100) / 100,
                orderLines: { create: orderLine }
            },
            include: orderInclude
        });
    });

    res.status(201).json(order);
});

// GET /api/orders  (comenzile utilizatorului curent)
router.get("/", async (req, res) => {
    const orders = await prisma.order.findMany({
        where: { userId: req.user.id },
        include: orderInclude,
        orderBy: { createdAt: "desc" }
    });

    res.json(orders);
});

router.get("/:id", async (req, res) => {
    const orderId = parseInt(req.params.id);

    const isAdmin = req.user.role === "ADMIN";

    const order = await prisma.order.findUnique({
        where: { id: orderId },
        include: orderInclude
    });

    if(!order){
        throw new HttpError(404, "Comanda nu exista");
    }

    if(order.userId !== req.user.id && !isAdmin){
        throw new HttpError(403, "Nu aveti permisiunea de a vizualiza aceasta comanda");
    }

    res.json(order);
});

router.patch("/:id/cancel", async (req, res) => {
    const orderId = parseInt(req.params.id);

    const order = await prisma.order.findUnique({
        where: { id: orderId }
    });

    if(!order){
        throw new HttpError(404, "Comanda nu exista");
    }

    if(order.status !== "PENDING"){
        throw new HttpError(409, "Comanda nu poate fi anulata");
    }

    if(order.userId !== req.user.id){
        throw new HttpError(403, "Nu aveti permisiunea de a vizualiza aceasta comanda");
    }


    const updatedOrder = await prisma.$transaction(async (tx) => {
        // restituim stocul produselor
        const orderLines = await tx.orderLine.findMany({
            where: { orderId: order.id }
        });

        for (const line of orderLines) {
            await tx.product.update({
                where: { id: line.productId },
                data: { stock: { increment: line.quantity } }
            });
        }

        return tx.order.update({
            where: { id: order.id },
            data: { status: "CANCELLED" },
            include: orderInclude
        });
    });

    res.json(updatedOrder);
});

export default router;
import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { authenticate } from "../middleware/auth.js";
import { HttpError } from "../utils/httpError.js";

const router = Router();

const orderInclude = {
    orderLines: {
        include: {
            product: { select: { id: true, name: true, imageUrl: true } }
        }
    }
};

const ALLOWED_STATUSES = ["PENDING", "PAID", "SHIPPED", "DELIVERED", "CANCELLED"];

// GET /api/admin/orders  (toate comenzile, admin view)
router.get("/orders",async (req, res) => {
    const orders = await prisma.order.findMany({
        include: orderInclude,
        orderBy: { createdAt: "desc" }
    });

    res.json(orders);
});

router.patch("/orders/:id/status", authenticate, async (req, res) => {
    const orderId = parseInt(req.params.id);
    const status = req.body.status;

    if (!ALLOWED_STATUSES.includes(status)) {
        throw new HttpError(400, "Status invalid");
    }

    const updatedOrder = await prisma.order.update({
        where: { id: orderId },
        data: { status },
        include: orderInclude
    });

    if(!updatedOrder){
        throw new HttpError(404, "Comanda nu exista");
    }

    res.json(updatedOrder);
});

export default router;
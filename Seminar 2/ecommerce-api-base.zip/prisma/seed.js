import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {

    await prisma.user.upsert({
        where: { email: "admin@shop.com" },
        update: {},
        create: {
            email: "admin@shop.com",
            name: "Admin",
            password: await bcrypt.hash("admin123", 10),
            role: "ADMIN"
        }
    });

    const products = [
        {
            name: "Laptop",
            price: 4000,
            category: "Electronics",
            stock: 10,
            imageUrl: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=600&q=80"
        },
        {
            name: "Phone",
            price: 2500,
            category: "Electronics",
            stock: 25,
            imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600&q=80"
        },
        {
            name: "Tablet",
            price: 1800,
            category: "Electronics",
            stock: 15,
            imageUrl: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=600&q=80"
        },
        {
            name: "Headphones",
            price: 350,
            category: "Electronics",
            stock: 40,
            imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&q=80"
        },
        {
            name: "Desk",
            price: 800,
            category: "Furniture",
            stock: 5,
            imageUrl: "https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=600&q=80"
        },
        {
            name: "Chair",
            price: 500,
            category: "Furniture",
            stock: 12,
            imageUrl: "https://images.unsplash.com/photo-1505843490538-5133c6c7d0e1?w=600&q=80"
        },
        {
            name: "Bookshelf",
            price: 650,
            category: "Furniture",
            stock: 0,
            imageUrl: "https://images.unsplash.com/photo-1594620302200-9a762244a156?w=600&q=80"
        }
    ];

    await prisma.orderLine.deleteMany();
    await prisma.order.deleteMany();
    await prisma.product.deleteMany();

    await prisma.product.createMany({
        data: products.map(product => ({
            ...product,
            description: `${product.name} - produs din categoria ${product.category}`
        }))
    });

    console.log("Seed finalizat");
}

main()
    .catch(error => {
        console.error(error);
        process.exit(1);
    })
    .finally(() => prisma.$disconnect());